Forked from Main VR Mod for Left 4 Dead 2. This is a configuration that sits on top of the original mod, you will need it for this mod to work. [Find it here](https://github.com/sd805/l4d2vr). 

***Alpha stages of building and testing. This should be functional but I need feedback.***. 

This provides CPU optimization, graphics improvements from other mods, and overall great baseline performance. 

- Download: [Releases](https://github.com/samfisherirl/Left4Dead2VR_HD_Remaster/releases)

- Files raw:  [Git](https://github.com/samfisherirl/Left4Dead2VR_HD_Remaster/tree/VR-HD-Remastered/l4d2%20-%20left4dead2%20-%20cfg)

[Demo Video](https://youtu.be/rcQBNVXs6Fg?t=44)

- Drop files in   "\Left 4 Dead 2\left4dead2\cfg" - usually C:\program files (86)\Steam\Steamapps\Common\ -

- Set launch options:
-insecure  -console +exec autoexec.cfg -precache_all_survivors 1  -useallavailablecores -window -novid -mat_motion_blur_percent_of_screen_max 0 -lv -refresh 120 -vphysics_client_threaded_min_cpus 4   vphysics_client_threaded 1

IF NOTHING ELSE, MULTICORE RENDERING MUST BE OFF IN GAME. 


Optional but highly ecouraged hd textures downloads, otherwise the game is just optimized for low end pc. 

 - HD Retexture pack
 - https://www.nexusmods.com/left4dead2/mods/84?tab=files&file_id=132

 - takes forever to downlaod so I uploaded to [my drive](https://drive.google.com/file/d/1OZ03HK9a5lNiir3I9vPcJLxOqWUDNNBj/view?usp=sharing). 

steam mod download tool https://steamworkshopdownloader.io/

 - https://steamcommunity.com/sharedfiles/filedetails/?id=1985083323 
 - Environment (Part 1 of 2) [ 4k / Full HD ]

 - https://steamcommunity.com/sharedfiles/filedetails/?id=312294075&searchtext=

in game settings

![image](https://user-images.githubusercontent.com/98753696/174659081-3de58da0-b556-4843-a8f1-eca6a13aeeec.png)\