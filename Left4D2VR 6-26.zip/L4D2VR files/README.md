How to download and install.

Downloading- This mod is currently split between myself and SD805, and we will soon be aligning on a combined place for releases.

Part 1) Get SD805’s latest release here

Part 2) Snag my latest release here

These two mods work in tandem. **If you wish to automatically install the mod, skip to 3b)** below.

Part 3a) Manually installing both mods is a simple drag and drop operation, finished by setting up launch options.

Take all files in both releases and locate your game directory.





For my half, find the “install” folder and then find “Drop these files into the game directory”. These will include both mine and SD805’s mods. You can also use the self extracting “install” zip.





Part 3b) Using the Installer - If you are manually installing files, you can skip ahead to Launch options or step 4 below. The main file in my release serves as an installer and launcher. “Left 4 Dead 2 VR Launcher and Installer” can be found in the main release file.

Install-Mod button





This tool will serve to install the game and be a launcher after installed.

4) Everyone should now be installed, make sure to save the “Installer and Launcher” folder, store it somewhere safe and create a desktop shortcut to use as a L4D2VR designated launcher.

5) Setting launch options is last, then its time to play. Almost there.

Copy these commands and right click on left4dead2 in your steam library, and click properties. At the bottom paste:

***-insecure -console +exec autoexec.cfg -precache_all_survivors 1 -useallavailablecores -window -novid -mat_motion_blur_percent_of_screen_max 0 -refresh 120 -vphysics_client_threaded_min_cpus 4 vphysics_client_threaded 1*** 

6) Now you can open the SteamVR app, and disable SteamVR Theater for L4D2, within the same menu.

Your settings should be appropriately set for you, aside from resolution. Your settings should look like this:





HOW TO PLAY

The moment you’ve been waiting for.

Once you’ve completed setup, use the “L4D2VR Launcher and Installer” to start the game.

Currently - navigating the menu isn’t fully done in-display. But! You don’t have to leave your headset for the keyboard.

The top left button says “Launch Game” at the top, and on the right it says engage VR.

1) Start in SteamVR Desktop Viewer. 2) Select Launch Game from L4D2VR Menu. 3) Leave the popup open, and navigate the L4D2 menu via SteamVR Desktop Viewer. 4) When you select a map, and the loading screen has finished, click the “Okay” button from the popup. Alternately, you can press “A” on the controller.

Welcome to LeftVRDead2.

Currently, I have not run across a mod that doesn’t work with the game. Feel free to test the limits. And make sure you provide feedback!

Credits: ****https://github.com/sd805/l4d2vr

sd805/l4d2vr

https://github.com/samfisherirl/Left4Dead2VR_HD_Remaster

Left4Dead2VR_HD_Remaster





Optional but highly encouraged hd textures downloads, otherwise the game is just optimized for low end pc.

  HD Retexture pack
  This takes forever to download so I uploaded to my drive here.
  
steam mod download tool https://steamworkshopdownloader.io/

  https://steamcommunity.com/sharedfiles/filedetails/?id=1985083323
  Environment (Part 1 of 2) [ 4k / Full HD ]
  https://steamcommunity.com/sharedfiles/filedetails/?id=312294075&searchtext=
  
in game settings (1080p, 2k, 4kw works):




